/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package con;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jhona
 */
public class Playlist {
    private List<String> songs;
    private PlaylistIterator iterator;

    public Playlist() {
        songs = new ArrayList<>();
        songs.add("Song 1 - Artist A");
        songs.add("Song 2 - Artist B");
        songs.add("Song 3 - Artist C");
        songs.add("Song 4 - Artist D");
        iterator = new PlaylistIterator(songs);
    }

    public PlaylistIterator getIterator() {
        return iterator;
    }
}
