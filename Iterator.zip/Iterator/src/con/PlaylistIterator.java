/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package con;

import it.SongIterator;
import java.util.List;

/**
 *
 * @author jhona
 */
public class PlaylistIterator implements SongIterator {
    private List<String> songs;
    private int position = 0;

    public PlaylistIterator(List<String> songs) {
        this.songs = songs;
    }

    @Override
    public boolean hasNext() {
        return position < songs.size() - 1;
    }

    @Override
    public String next() {
        if (hasNext()) {
            return songs.get(++position);
        }
        return songs.get(position);
    }

    @Override
    public boolean hasPrevious() {
        return position > 0;
    }

    @Override
    public String previous() {
        if (hasPrevious()) {
            return songs.get(--position);
        }
        return songs.get(position);
    }
    
    public String getCurrentSong() {
        return songs.get(position);
    }
}
