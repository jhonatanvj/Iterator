/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package it;

/**
 *
 * @author jhona
 */
public interface SongIterator {
    boolean hasNext();
    String next();
    boolean hasPrevious();
    String previous();
}
