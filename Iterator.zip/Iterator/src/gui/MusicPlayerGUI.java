/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import con.Playlist;
import con.PlaylistIterator;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

/**
 *
 * @author jhona
 */
public class MusicPlayerGUI {
    private JFrame frame;
    private JLabel songLabel;
    private JButton playButton, nextButton, prevButton;
    private Playlist playlist;
    private PlaylistIterator iterator;

    public MusicPlayerGUI() {
        playlist = new Playlist();
        iterator = playlist.getIterator();
        
        frame = new JFrame("🎵 Music Player 🎵");
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(30, 30, 30));

        songLabel = new JLabel(iterator.getCurrentSong(), SwingConstants.CENTER);
        songLabel.setFont(new Font("Arial", Font.BOLD, 20));
        songLabel.setForeground(Color.WHITE);
        frame.add(songLabel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 3, 10, 10));
        buttonPanel.setBackground(new Color(50, 50, 50));
        
        playButton = new JButton("Play");
        nextButton = new JButton("Next");
        prevButton = new JButton("Previous");
        
        styleButton(playButton);
        styleButton(nextButton);
        styleButton(prevButton);
        
        buttonPanel.add(prevButton);
        buttonPanel.add(playButton);
        buttonPanel.add(nextButton);
        
        frame.add(buttonPanel, BorderLayout.SOUTH);
        
        // Eventos de los botones
        playButton.addActionListener(e -> JOptionPane.showMessageDialog(frame, "🎶 Playing: " + iterator.getCurrentSong()));
        
        nextButton.addActionListener(e -> {
            songLabel.setText(iterator.next());
        });
        
        prevButton.addActionListener(e -> {
            songLabel.setText(iterator.previous());
        });
        
        frame.setVisible(true);
    }
    
    private void styleButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(70, 70, 70));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(MusicPlayerGUI::new);
    }
}

